package mytld.mycompany.myapp;

public interface Service {
	
	String getMessage();

}
